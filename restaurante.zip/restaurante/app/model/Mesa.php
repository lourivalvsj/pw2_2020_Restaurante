<?php


namespace model;


class Mesa{

    private $id;
    private $descricao;
    private $lugares;
    private $posicao;

    /**
     * @return mixed
     */
    public function getId(){
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id){
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getDescricao(){
        return $this->descricao;
    }

    /**
     * @param mixed $descricao
     */
    public function setDescricao($descricao){
        $this->descricao = $descricao;
    }

    /**
     * @return mixed
     */
    public function getLugares(){
        return $this->lugares;
    }

    /**
     * @param mixed $lugares
     */
    public function setLugares($lugares) {
        $this->lugares = $lugares;
    }

    /**
     * @return mixed
     */
    public function getPosicao(){
        return $this->posicao;
    }

    /**
     * @param mixed $posicao
     */
    public function setPosicao($posicao){
        $this->posicao = $posicao;
    }
}
