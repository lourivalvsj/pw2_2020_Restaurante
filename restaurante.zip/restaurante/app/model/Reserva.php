<?php


namespace model;

use model\Usuario;
use model\Cliente;
use model\Mesa;


class Reserva{
    //private $idReserva;
    //private $idCliente;
    //private $idMesa;
    //private $dataReserva;
    //private $idUsuario
    private $id;
    private $usuario;
    private $cliente;
    private $mesa;
    private $dataReserva;

    /**
     * Reserva constructor.
     */
    public function __construct(){
        $this->usuario = new \model\Usuario();
        $this->mesa = new \model\Mesa();
        $this->cliente = new \model\Cliente();
    }
    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getUsuario()
    {
        return $this->usuario;
    }

    /**
     * @param mixed $usuario
     */
    public function setUsuario($usuario)
    {
        $this->usuario = $usuario;
    }

    /**
     * @return mixed
     */
    public function getCliente()
    {
        return $this->cliente;
    }

    /**
     * @param mixed $cliente
     */
    public function setCliente($cliente)
    {
        $this->cliente = $cliente;
    }

    /**
     * @return mixed
     */
    public function getMesa()
    {
        return $this->mesa;
    }

    /**
     * @param mixed $mesa
     */
    public function setMesa($mesa)
    {
        $this->mesa = $mesa;
    }

    /**
     * @return mixed
     */
    public function getDataReserva()
    {
        return $this->dataReserva;
    }

    /**
     * @param mixed $dataReserva
     */
    public function setDataReserva($dataReserva)
    {
        $this->dataReserva = $dataReserva;
    }

}