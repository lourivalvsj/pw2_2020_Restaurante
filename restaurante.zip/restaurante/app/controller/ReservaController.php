<?php


namespace controller;
use model\Reserva;
include_once "Conexao.php";
class ReservaController{
    private static $instance;
    private $conexao;

    private function __construct(){
        $this->conexao = Conexao::getInstance();
    }

    public static function getInstance(){
        if (self::$instance == null){
            self::$instance = new ReservaController();
        }
        return self::$instance;
    }

    private function inserir(Reserva $reserva){
        $sql = "INSERT INTO reserva (idCliente, idMesa, dataReserva, idUsuario) VALUES 
                ( :idCliente, :idMesa, :dataReserva, :idUsuario)";

        $p_sql = $this->conexao->prepare($sql);
        $p_sql->bindValue(":idCliente", $reserva->getCliente()->getId());
        $p_sql->bindValue(":idMesa", $reserva->getMesa()->getId());
        $p_sql->bindValue(":dataReserva", $reserva->getDataReserva());
        $p_sql->bindValue(":idUsuario", $reserva->getUsuario()->getId());
        return $p_sql->execute();
    }

    public function gravar(Reserva $reserva){
        if ($reserva->getId() > 0){
            return false;
        }else{
            return $this->inserir($reserva);
        }
    }

       public function buscarReserva($dataReserva){
        $lstReserva =array();
        $sql = "SELECT cliente.nome as cliente, 
		mesa.descricao as mesaDescricao,
        mesa.lugares as mesaLugares,
        mesa.posicao as mesaPosicao,
        usuario.nome as usuario, 
        reserva.dataReserva as dataReserva
        FROM reserva 
            JOIN cliente ON(reserva.idCliente = cliente.id) 
			JOIN mesa ON(reserva.idMesa = mesa.id)
            JOIN usuario ON(reserva.idUsuario = usuario.id) 
            WHERE dataReserva = :dataReserva ORDER BY usuario.nome";

        $p_sql = $this->conexao->prepare($sql);
        $p_sql->bindValue(":dataReserva", $dataReserva);
        $p_sql->execute();
        $retornoSQL = $p_sql->fetchAll(\PDO::FETCH_ASSOC);

        foreach ($retornoSQL as $row){
            $reserva = $this->preencherDados($row);
            $lstReserva[]=$reserva;
        }
        return $lstReserva;
    }

    private function preencherDados($row){
        $reserva = new Reserva();
        $reserva->getCliente()->setNome($row['cliente']);
        $reserva->getMesa()->setDescricao($row['mesaDescricao']);
        $reserva->getMesa()->setLugares($row['mesaLugares']);
        $reserva->getMesa()->setPosicao($row['mesaPosicao']);
        $reserva->getUsuario()->setNome($row['usuario']);
        $reserva->setDataReserva($row['dataReserva']);
        return $reserva;
    }

}