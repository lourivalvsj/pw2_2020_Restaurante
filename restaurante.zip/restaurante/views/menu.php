<li class="nav-item">
    <a class="nav-link" href="listaClientes.php">
        <span>Clientes</span></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="listaMesas.php">
        <span>Mesas</span></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="listaReservas.php">
        <span>Reservas</span></a>
</li>
